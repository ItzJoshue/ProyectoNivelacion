import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import json
import uuid

# ============================================================
# ALMACENAMIENTO JSON SEGURO
# ============================================================

def obtener_carpeta_datos():
    home = Path.home()
    posibles = [
        home / "Documents" / "Sistema_ULEAM_JSON_DATA",
        home / "Documentos" / "Sistema_ULEAM_JSON_DATA",
        home / "Sistema_ULEAM_JSON_DATA",
        Path.cwd() / "Sistema_ULEAM_JSON_DATA"
    ]

    for carpeta in posibles:
        try:
            carpeta.mkdir(parents=True, exist_ok=True)
            prueba = carpeta / "prueba_escritura.txt"
            prueba.write_text("ok", encoding="utf-8")
            prueba.unlink(missing_ok=True)
            return carpeta
        except Exception:
            pass

    raise RuntimeError("No se pudo crear una carpeta para guardar los datos JSON.")

DATA_DIR = obtener_carpeta_datos()

ARCHIVOS = {
    "estudiantes": DATA_DIR / "estudiantes.json",
    "profesores": DATA_DIR / "profesores.json",
    "aulas": DATA_DIR / "aulas.json",
    "cursos": DATA_DIR / "cursos.json",
    "postulantes": DATA_DIR / "postulantes.json",
    "matriculas": DATA_DIR / "matriculas.json",
}

def iniciar_json():
    for ruta in ARCHIVOS.values():
        ruta.parent.mkdir(parents=True, exist_ok=True)
        if not ruta.exists():
            ruta.write_text("[]", encoding="utf-8")

def leer_json(nombre):
    ruta = ARCHIVOS[nombre]
    try:
        if not ruta.exists():
            ruta.write_text("[]", encoding="utf-8")

        texto = ruta.read_text(encoding="utf-8").strip()
        if not texto:
            return []

        datos = json.loads(texto)
        return datos if isinstance(datos, list) else []
    except json.JSONDecodeError:
        ruta.write_text("[]", encoding="utf-8")
        messagebox.showwarning("JSON reiniciado", f"El archivo {ruta.name} estaba dañado y fue reiniciado.")
        return []
    except Exception as e:
        messagebox.showerror("Error de lectura", f"No se pudo leer:\n{ruta}\n\n{e}")
        return []

def guardar_json(nombre, datos):
    ruta = ARCHIVOS[nombre]
    try:
        ruta.parent.mkdir(parents=True, exist_ok=True)
        with open(ruta, "w", encoding="utf-8") as archivo:
            json.dump(datos, archivo, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        messagebox.showerror("Error de guardado", f"No se pudo guardar:\n{ruta}\n\n{e}")
        return False

def nuevo_id(prefijo):
    return f"{prefijo}-{uuid.uuid4().hex[:6].upper()}"

# ============================================================
# FRAME CRUD GENERAL
# ============================================================

class CrudFrame(tk.Frame):
    def __init__(self, parent, titulo, archivo, campos, columnas):
        super().__init__(parent, bg="#eaf6ff")
        self.archivo = archivo
        self.campos = campos
        self.columnas = columnas
        self.vars = {}
        self.id_seleccionado = None

        tk.Label(
            self, text=titulo, bg="#eaf6ff", fg="black",
            font=("Arial", 18, "bold")
        ).pack(anchor="w", pady=(0, 12))

        formulario = tk.Frame(self, bg="white", padx=10, pady=8)
        formulario.pack(fill="x")

        for i, campo in enumerate(campos):
            fila = i // 2
            col = (i % 2) * 2

            tk.Label(formulario, text=campo.capitalize(), bg="white", fg="black").grid(
                row=fila, column=col, sticky="w", padx=6, pady=6
            )

            var = tk.StringVar()
            entrada = tk.Entry(formulario, textvariable=var, width=42)
            entrada.grid(row=fila, column=col + 1, sticky="ew", padx=6, pady=6)
            self.vars[campo] = var

        botones = tk.Frame(self, bg="#eaf6ff")
        botones.pack(fill="x", pady=10)

        tk.Button(botones, text="Guardar", width=14, command=self.guardar).pack(side="left", padx=4)
        tk.Button(botones, text="Actualizar", width=14, command=self.actualizar).pack(side="left", padx=4)
        tk.Button(botones, text="Eliminar", width=14, command=self.eliminar).pack(side="left", padx=4)
        tk.Button(botones, text="Limpiar", width=14, command=self.limpiar).pack(side="left", padx=4)

        marco_tabla = tk.Frame(self, bg="white")
        marco_tabla.pack(fill="both", expand=True)

        self.tabla = ttk.Treeview(marco_tabla, columns=columnas, show="headings")
        scroll_y = ttk.Scrollbar(marco_tabla, orient="vertical", command=self.tabla.yview)
        scroll_x = ttk.Scrollbar(marco_tabla, orient="horizontal", command=self.tabla.xview)

        self.tabla.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)

        for col in columnas:
            self.tabla.heading(col, text=col.upper())
            self.tabla.column(col, width=145, anchor="center")

        self.tabla.grid(row=0, column=0, sticky="nsew")
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x.grid(row=1, column=0, sticky="ew")

        marco_tabla.rowconfigure(0, weight=1)
        marco_tabla.columnconfigure(0, weight=1)

        self.tabla.bind("<<TreeviewSelect>>", self.cargar_seleccion)
        self.refrescar()

    def validar(self):
        for campo, var in self.vars.items():
            if not var.get().strip():
                messagebox.showwarning("Validación", f"El campo '{campo}' es obligatorio.")
                return False

        if self.archivo == "aulas":
            try:
                if int(self.vars["capacidad"].get()) <= 0:
                    raise ValueError
            except Exception:
                messagebox.showwarning("Validación", "La capacidad debe ser un número mayor a 0.")
                return False

        if self.archivo == "cursos":
            try:
                if int(self.vars["cupos"].get()) <= 0:
                    raise ValueError
            except Exception:
                messagebox.showwarning("Validación", "Los cupos deben ser un número mayor a 0.")
                return False

        if self.archivo == "postulantes":
            try:
                if float(self.vars["puntaje"].get()) < 0:
                    raise ValueError
            except Exception:
                messagebox.showwarning("Validación", "El puntaje debe ser un número válido.")
                return False

        return True

    def guardar(self):
        if not self.validar():
            return

        datos = leer_json(self.archivo)

        if "cedula" in self.vars:
            cedula = self.vars["cedula"].get().strip()
            if any(item.get("cedula") == cedula for item in datos):
                messagebox.showwarning("Duplicado", "Ya existe un registro con esa cédula.")
                return

        if "codigo" in self.vars:
            codigo = self.vars["codigo"].get().strip()
            if any(item.get("codigo") == codigo for item in datos):
                messagebox.showwarning("Duplicado", "Ya existe un aula con ese código.")
                return

        nuevo = {"id": nuevo_id(self.archivo[:3].upper())}
        for campo, var in self.vars.items():
            nuevo[campo] = var.get().strip()

        datos.append(nuevo)

        if guardar_json(self.archivo, datos):
            self.refrescar()
            self.limpiar()
            messagebox.showinfo("Correcto", "Registro guardado correctamente.")

    def actualizar(self):
        if not self.id_seleccionado:
            messagebox.showwarning("Aviso", "Primero selecciona un registro.")
            return

        if not self.validar():
            return

        datos = leer_json(self.archivo)

        for item in datos:
            if item.get("id") == self.id_seleccionado:
                for campo, var in self.vars.items():
                    item[campo] = var.get().strip()

        if guardar_json(self.archivo, datos):
            self.refrescar()
            self.limpiar()
            messagebox.showinfo("Correcto", "Registro actualizado correctamente.")

    def eliminar(self):
        if not self.id_seleccionado:
            messagebox.showwarning("Aviso", "Primero selecciona un registro.")
            return

        if not messagebox.askyesno("Confirmar", "¿Seguro que deseas eliminar este registro?"):
            return

        datos = leer_json(self.archivo)
        datos = [item for item in datos if item.get("id") != self.id_seleccionado]

        if guardar_json(self.archivo, datos):
            self.refrescar()
            self.limpiar()
            messagebox.showinfo("Correcto", "Registro eliminado correctamente.")

    def limpiar(self):
        self.id_seleccionado = None
        for var in self.vars.values():
            var.set("")
        for sel in self.tabla.selection():
            self.tabla.selection_remove(sel)

    def refrescar(self):
        for item in self.tabla.get_children():
            self.tabla.delete(item)

        for registro in leer_json(self.archivo):
            valores = [registro.get(col, "") for col in self.columnas]
            self.tabla.insert("", "end", values=valores)

    def cargar_seleccion(self, event=None):
        seleccion = self.tabla.selection()
        if not seleccion:
            return

        valores = self.tabla.item(seleccion[0], "values")
        if not valores:
            return

        self.id_seleccionado = valores[0]
        datos = leer_json(self.archivo)

        registro = next((item for item in datos if item.get("id") == self.id_seleccionado), None)

        if registro:
            for campo in self.campos:
                self.vars[campo].set(registro.get(campo, ""))

# ============================================================
# MATRÍCULAS
# ============================================================

class MatriculaFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="#eaf6ff")

        tk.Label(
            self, text="Gestión de Matrículas", bg="#eaf6ff", fg="black",
            font=("Arial", 18, "bold")
        ).pack(anchor="w", pady=(0, 12))

        formulario = tk.Frame(self, bg="white", padx=10, pady=10)
        formulario.pack(fill="x")

        self.est_var = tk.StringVar()
        self.cur_var = tk.StringVar()
        self.aula_var = tk.StringVar()

        tk.Label(formulario, text="Estudiante", bg="white").grid(row=0, column=0, sticky="w", padx=6, pady=6)
        self.combo_est = ttk.Combobox(formulario, textvariable=self.est_var, width=60, state="readonly")
        self.combo_est.grid(row=0, column=1, padx=6, pady=6)

        tk.Label(formulario, text="Curso", bg="white").grid(row=1, column=0, sticky="w", padx=6, pady=6)
        self.combo_cur = ttk.Combobox(formulario, textvariable=self.cur_var, width=60, state="readonly")
        self.combo_cur.grid(row=1, column=1, padx=6, pady=6)

        tk.Label(formulario, text="Aula", bg="white").grid(row=2, column=0, sticky="w", padx=6, pady=6)
        self.combo_aula = ttk.Combobox(formulario, textvariable=self.aula_var, width=60, state="readonly")
        self.combo_aula.grid(row=2, column=1, padx=6, pady=6)

        tk.Button(formulario, text="Recargar listas", width=16, command=self.cargar_listas).grid(row=3, column=0, padx=6, pady=8)
        tk.Button(formulario, text="Matricular", width=16, command=self.matricular).grid(row=3, column=1, sticky="e", padx=6, pady=8)

        self.tabla = ttk.Treeview(self, columns=("id", "estudiante", "curso", "aula"), show="headings")
        for col in ("id", "estudiante", "curso", "aula"):
            self.tabla.heading(col, text=col.upper())
            self.tabla.column(col, width=200, anchor="center")
        self.tabla.pack(fill="both", expand=True, pady=10)

        self.cargar_listas()
        self.refrescar()

    def cargar_listas(self):
        self.estudiantes = leer_json("estudiantes")
        self.cursos = leer_json("cursos")
        self.aulas = leer_json("aulas")

        self.combo_est["values"] = [
            f'{e.get("id")} | {e.get("nombre")} | {e.get("cedula")}' for e in self.estudiantes
        ]
        self.combo_cur["values"] = [
            f'{c.get("id")} | {c.get("nombre")} | cupos: {c.get("cupos")}' for c in self.cursos
        ]
        self.combo_aula["values"] = [
            f'{a.get("id")} | {a.get("codigo")} | capacidad: {a.get("capacidad")}' for a in self.aulas
        ]

    def obtener_id(self, texto):
        return texto.split("|")[0].strip() if texto else ""

    def matricular(self):
        estudiante_id = self.obtener_id(self.est_var.get())
        curso_id = self.obtener_id(self.cur_var.get())
        aula_id = self.obtener_id(self.aula_var.get())

        if not estudiante_id or not curso_id or not aula_id:
            messagebox.showwarning("Validación", "Debes seleccionar estudiante, curso y aula.")
            return

        matriculas = leer_json("matriculas")

        if any(m.get("estudiante_id") == estudiante_id and m.get("curso_id") == curso_id for m in matriculas):
            messagebox.showwarning("Duplicado", "Este estudiante ya está matriculado en ese curso.")
            return

        cursos = leer_json("cursos")
        curso = next((c for c in cursos if c.get("id") == curso_id), None)

        if curso:
            try:
                cupos = int(curso.get("cupos", "0"))
            except Exception:
                cupos = 0

            ocupados = len([m for m in matriculas if m.get("curso_id") == curso_id])
            if ocupados >= cupos:
                messagebox.showwarning("Sin cupos", "El curso seleccionado ya no tiene cupos disponibles.")
                return

        nueva = {
            "id": nuevo_id("MAT"),
            "estudiante_id": estudiante_id,
            "curso_id": curso_id,
            "aula_id": aula_id
        }

        matriculas.append(nueva)

        if guardar_json("matriculas", matriculas):
            self.refrescar()
            messagebox.showinfo("Correcto", "Matrícula registrada correctamente.")

    def refrescar(self):
        for item in self.tabla.get_children():
            self.tabla.delete(item)

        estudiantes = {e.get("id"): e.get("nombre") for e in leer_json("estudiantes")}
        cursos = {c.get("id"): c.get("nombre") for c in leer_json("cursos")}
        aulas = {a.get("id"): a.get("codigo") for a in leer_json("aulas")}

        for m in leer_json("matriculas"):
            self.tabla.insert("", "end", values=(
                m.get("id", ""),
                estudiantes.get(m.get("estudiante_id"), ""),
                cursos.get(m.get("curso_id"), ""),
                aulas.get(m.get("aula_id"), "")
            ))

# ============================================================
# REPORTES
# ============================================================

class ReporteFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="#eaf6ff")

        tk.Label(
            self, text="Reportes", bg="#eaf6ff", fg="black",
            font=("Arial", 18, "bold")
        ).pack(anchor="w", pady=(0, 12))

        botones = tk.Frame(self, bg="#eaf6ff")
        botones.pack(fill="x", pady=5)

        tk.Button(botones, text="Generar reporte", width=18, command=self.generar).pack(side="left", padx=4)
        tk.Button(botones, text="Ver carpeta JSON", width=18, command=self.ver_ruta).pack(side="left", padx=4)

        self.texto = tk.Text(self, bg="white", fg="black", font=("Consolas", 10))
        self.texto.pack(fill="both", expand=True, pady=8)

    def ver_ruta(self):
        messagebox.showinfo("Carpeta de datos", f"Los JSON se guardan en:\n{DATA_DIR}")

    def generar(self):
        self.texto.delete("1.0", "end")

        estudiantes = leer_json("estudiantes")
        profesores = leer_json("profesores")
        aulas = leer_json("aulas")
        cursos = leer_json("cursos")
        postulantes = leer_json("postulantes")
        matriculas = leer_json("matriculas")

        self.texto.insert("end", "===== REPORTE GENERAL ULEAM =====\n\n")
        self.texto.insert("end", f"Carpeta JSON: {DATA_DIR}\n\n")
        self.texto.insert("end", f"Estudiantes:  {len(estudiantes)}\n")
        self.texto.insert("end", f"Profesores:   {len(profesores)}\n")
        self.texto.insert("end", f"Aulas:        {len(aulas)}\n")
        self.texto.insert("end", f"Cursos:       {len(cursos)}\n")
        self.texto.insert("end", f"Postulantes:  {len(postulantes)}\n")
        self.texto.insert("end", f"Matrículas:   {len(matriculas)}\n\n")

        self.texto.insert("end", "===== MATRÍCULAS =====\n")
        estudiantes_dict = {e.get("id"): e.get("nombre") for e in estudiantes}
        cursos_dict = {c.get("id"): c.get("nombre") for c in cursos}
        aulas_dict = {a.get("id"): a.get("codigo") for a in aulas}

        if not matriculas:
            self.texto.insert("end", "No hay matrículas registradas.\n")
        else:
            for m in matriculas:
                self.texto.insert(
                    "end",
                    f"- {estudiantes_dict.get(m.get('estudiante_id'), 'N/D')} | "
                    f"{cursos_dict.get(m.get('curso_id'), 'N/D')} | "
                    f"Aula {aulas_dict.get(m.get('aula_id'), 'N/D')}\n"
                )

# ============================================================
# APP PRINCIPAL
# ============================================================

class App:
    def __init__(self, root):
        iniciar_json()

        self.root = root
        self.root.title("Sistema Académico ULEAM - G4")
        self.root.geometry("1120x720")
        self.root.configure(bg="#eaf6ff")

        encabezado = tk.Frame(root, bg="#eaf6ff")
        encabezado.pack(fill="x", padx=24, pady=14)

        tk.Label(
            encabezado, text="Sistema Académico ULEAM", bg="#eaf6ff",
            fg="black", font=("Arial", 22, "bold")
        ).pack(side="left")

        tk.Label(
            encabezado, text="G4", bg="#eaf6ff",
            fg="black", font=("Arial", 12)
        ).pack(side="right")

        cuerpo = tk.Frame(root, bg="#eaf6ff")
        cuerpo.pack(fill="both", expand=True, padx=14, pady=10)

        menu = tk.Frame(cuerpo, bg="#bdeaff", width=195)
        menu.pack(side="left", fill="y", padx=(0, 20))
        menu.pack_propagate(False)

        self.contenido = tk.Frame(cuerpo, bg="#eaf6ff")
        self.contenido.pack(side="left", fill="both", expand=True)

        opciones = [
            ("Estudiantes", self.ver_estudiantes),
            ("Profesores", self.ver_profesores),
            ("Aulas", self.ver_aulas),
            ("Cursos", self.ver_cursos),
            ("Postulantes", self.ver_postulantes),
            ("Matrículas", self.ver_matriculas),
            ("Reportes", self.ver_reportes),
        ]

        for texto, comando in opciones:
            tk.Button(
                menu, text=texto, command=comando, bg="white", fg="black",
                width=18, height=2, relief="flat"
            ).pack(pady=7)

        self.ver_estudiantes()

    def limpiar_contenido(self):
        for widget in self.contenido.winfo_children():
            widget.destroy()

    def ver_estudiantes(self):
        self.limpiar_contenido()
        frame = CrudFrame(
            self.contenido,
            "Gestión de Estudiantes",
            "estudiantes",
            ["nombre", "cedula", "carrera", "correo"],
            ["id", "nombre", "cedula", "carrera", "correo"]
        )
        frame.pack(fill="both", expand=True)

    def ver_profesores(self):
        self.limpiar_contenido()
        frame = CrudFrame(
            self.contenido,
            "Gestión de Profesores",
            "profesores",
            ["nombre", "cedula", "materia", "correo"],
            ["id", "nombre", "cedula", "materia", "correo"]
        )
        frame.pack(fill="both", expand=True)

    def ver_aulas(self):
        self.limpiar_contenido()
        frame = CrudFrame(
            self.contenido,
            "Gestión de Aulas",
            "aulas",
            ["codigo", "capacidad"],
            ["id", "codigo", "capacidad"]
        )
        frame.pack(fill="both", expand=True)

    def ver_cursos(self):
        self.limpiar_contenido()
        frame = CrudFrame(
            self.contenido,
            "Gestión de Cursos",
            "cursos",
            ["nombre", "carrera", "cupos"],
            ["id", "nombre", "carrera", "cupos"]
        )
        frame.pack(fill="both", expand=True)

    def ver_postulantes(self):
        self.limpiar_contenido()
        frame = CrudFrame(
            self.contenido,
            "Gestión de Postulantes",
            "postulantes",
            ["nombre", "cedula", "carrera", "puntaje", "correo"],
            ["id", "nombre", "cedula", "carrera", "puntaje", "correo"]
        )
        frame.pack(fill="both", expand=True)

    def ver_matriculas(self):
        self.limpiar_contenido()
        frame = MatriculaFrame(self.contenido)
        frame.pack(fill="both", expand=True)

    def ver_reportes(self):
        self.limpiar_contenido()
        frame = ReporteFrame(self.contenido)
        frame.pack(fill="both", expand=True)

if __name__ == "__main__":
    try:
        ventana = tk.Tk()
        App(ventana)
        ventana.mainloop()
    except Exception as error:
        try:
            messagebox.showerror("Error crítico", str(error))
        except Exception:
            print(error)