# Sistema Académico ULEAM - POO4


## Errores solucionados



## Qué cambió


## Datos JSON



## Ejecutar

```bash
python main.py
```